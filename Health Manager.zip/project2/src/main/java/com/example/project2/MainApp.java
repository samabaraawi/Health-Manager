package com.example.project2;

import ds.*;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainApp extends Application {

    private final PatientManager patientManager = new PatientManager();
    private final ConditionManager conditionManager = new ConditionManager();
    private final FileLoader fileLoader = new FileLoader();
    private final SymptomsTab symptomsTab = new SymptomsTab(patientManager);

    private Scene scene;
    private BorderPane mainRoot;
    private TabPane tabPane;
    private HBox headerBar;
    private boolean darkMode = false;

    private Tab dashboardTab;

    @Override
    public void start(Stage stage) {
        showSplash(stage);
    }

    //Splash Screen
    private void showSplash(Stage stage) {
        Label title = new Label("Health Manager");
        title.setStyle(
                "-fx-text-fill: white;" +
                        "-fx-font-size: 40px;" +
                        "-fx-font-weight: bold;"
        );

        Label subtitle = new Label("Smart Health & Treatment Tracking System");
        subtitle.setStyle(
                "-fx-text-fill: rgba(255,255,255,0.85);" +
                        "-fx-font-size: 18px;"
        );

        ProgressBar bar = new ProgressBar();
        bar.setPrefWidth(260);
        bar.setStyle("-fx-accent: #80deea;");

        VBox box = new VBox(16, title, subtitle, bar);
        box.setAlignment(Pos.CENTER);

        StackPane splashRoot = new StackPane(box);
        splashRoot.setPadding(new Insets(30));
        splashRoot.setStyle(
                "-fx-background-color: linear-gradient(to bottom right, #1e88e5, #7b1fa2);"
        );

        Scene splashScene = new Scene(splashRoot, 1000, 650);
        stage.setScene(splashScene);
        stage.setTitle("Health Manager");
        stage.show();

        PauseTransition pt = new PauseTransition(Duration.seconds(2.5));
        pt.setOnFinished(e -> initMainUI(stage));
        pt.play();
    }

    //Main UI
    private void initMainUI(Stage stage) {
        //Managers Tabs
        LoadDataTab loadDataTab = new LoadDataTab(fileLoader, patientManager, conditionManager);
        PatientsTab patientsTab = new PatientsTab(patientManager, conditionManager);
        TreatmentsTab treatmentsTab = new TreatmentsTab(patientManager, conditionManager);
        MedicationsTab medicationsTab = new MedicationsTab(patientManager, conditionManager);
        ConditionsTab conditionsTab = new ConditionsTab(conditionManager);
        ReportsTab reportsTab = new ReportsTab(patientManager, conditionManager);

        // Dashboard tab (the first tab)
        dashboardTab = new Tab("Dashboard");
        dashboardTab.setClosable(false);
        dashboardTab.setContent(buildDashboardContent());
        dashboardTab.setGraphic(new Label("🏠"));

        // connecting the load tab with the other tabs + the dashboard
        loadDataTab.setOnAfterLoad(() -> {
            patientsTab.refreshTable();
            treatmentsTab.refreshTable();
            medicationsTab.refreshTable();
            conditionsTab.refreshTable();
            symptomsTab.refreshAll();
            reportsTab.refreshIntro();
            refreshDashboard();
        });

        tabPane = new TabPane(
                dashboardTab,
                loadDataTab,
                patientsTab,
                treatmentsTab,
                medicationsTab,
                conditionsTab,
                symptomsTab,
                reportsTab
        );

        // Icons for the tabs
        loadDataTab.setGraphic(new Label("📂"));
        patientsTab.setGraphic(new Label("👤"));
        treatmentsTab.setGraphic(new Label("💉"));
        medicationsTab.setGraphic(new Label("💊"));
        conditionsTab.setGraphic(new Label("⚕️"));
        symptomsTab.setGraphic(new Label("🤒"));
        reportsTab.setGraphic(new Label("📊"));

        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.setSide(Side.LEFT);
        tabPane.setTabMinWidth(150);
        tabPane.setTabMaxWidth(180);
        tabPane.setStyle(
                "-fx-background-color: transparent;" +
                        "-fx-open-tab-animation: NONE;" +
                        "-fx-close-tab-animation: NONE;"
        );

        // Animation when switching tabs
        // Animation + refreshing the dashboard when selecting the tab
        tabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab == dashboardTab) {
                // refreshing the dashboard with every action "adding , removing......"
                refreshDashboard();
            }

            if (newTab != null && newTab.getContent() != null) {
                FadeTransition ft = new FadeTransition(Duration.millis(300), newTab.getContent());
                newTab.getContent().setOpacity(0);
                ft.setFromValue(0);
                ft.setToValue(1);
                ft.play();
            }
        });


        //Header bar (the adress and the button theam)
        Label titleLabel = new Label("Health Manager");
        titleLabel.setStyle(
                "-fx-font-size: 24px;" +
                        "-fx-font-weight: bold;"
        );

        Label subtitleLabel = new Label("Patients • Conditions • Treatments • Medications • Symptoms");
        subtitleLabel.setStyle(
                "-fx-font-size: 12px;" +
                        "-fx-text-fill: #607d8b;"
        );

        VBox titleBox = new VBox(2, titleLabel, subtitleLabel);

        ToggleButton themeToggle = new ToggleButton("🌙 Dark");
        themeToggle.setOnAction(e -> {
            darkMode = themeToggle.isSelected();
            themeToggle.setText(darkMode ? "☀️ Light" : "🌙 Dark");
            applyTheme();
        });
        themeToggle.setStyle(
                "-fx-background-radius: 20;" +
                        "-fx-padding: 6 14;" +
                        "-fx-font-size: 12px;"
        );

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        headerBar = new HBox(10, titleBox, spacer, themeToggle);
        headerBar.setAlignment(Pos.CENTER_LEFT);
        headerBar.setPadding(new Insets(10, 16, 10, 16));
        headerBar.setStyle(
                "-fx-background-radius: 0 0 18 18;" +
                        "-fx-border-radius: 0 0 18 18;" +
                        "-fx-border-width: 0 0 1 0;" +
                        "-fx-border-color: rgba(0,0,0,0.08);"
        );

        //Root Layout
        mainRoot = new BorderPane();
        mainRoot.setTop(headerBar);
        mainRoot.setCenter(tabPane);
        mainRoot.setPadding(new Insets(8));

        applyTheme(); //  the default theam (Light)

        scene = new Scene(mainRoot, 1000, 650);
        stage.setScene(scene);
        stage.show();
    }

    //Dashboard
    private void refreshDashboard() {
        if (dashboardTab != null) {
            dashboardTab.setContent(buildDashboardContent());
        }
    }

    private Pane buildDashboardContent() {
        int totalPatients = patientManager.count();
        int totalConditions = conditionManager.count();

        int totalTreatments = 0;
        int totalMedications = 0;

        CircularDoublyLinkedList<Patient> ps = patientManager.getPatients();
        int pn = ps.getSize();
        for (int i = 0; i < pn; i++) {
            Patient p = ps.get(i);
            if (p == null) continue;
            totalTreatments += (p.getTreatments() == null ? 0 : p.getTreatments().getSize());
            totalMedications += (p.getMeds() == null ? 0 : p.getMeds().getSize());
        }

        //Card helper
        VBox card1 = buildMetricCard("Patients", String.valueOf(totalPatients), "👥");
        VBox card2 = buildMetricCard("Conditions", String.valueOf(totalConditions), "⚕️");
        VBox card3 = buildMetricCard("Treatments", String.valueOf(totalTreatments), "💉");
        VBox card4 = buildMetricCard("Medications", String.valueOf(totalMedications), "💊");

        HBox cardsRow = new HBox(16, card1, card2, card3, card4);
        cardsRow.setPadding(new Insets(20, 20, 10, 20));
        cardsRow.setAlignment(Pos.CENTER);
        cardsRow.setFillHeight(true);

        Label welcome = new Label("Welcome to Health Manager Dashboard");
        welcome.setStyle(
                "-fx-font-size: 20px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #37474f;"
        );

        Label info = new Label(
                "Track patients, conditions, treatments, medications, and symptoms in one place.\n" +
                        "Use the sidebar to navigate between modules, load data, and generate reports."
        );
        info.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #607d8b;"
        );

        VBox centerBox = new VBox(10, welcome, info);
        centerBox.setAlignment(Pos.TOP_LEFT);
        centerBox.setPadding(new Insets(10, 20, 20, 20));

        BorderPane pane = new BorderPane();
        pane.setTop(cardsRow);
        pane.setCenter(centerBox);
        pane.setPadding(new Insets(10));

        return pane;
    }

    private VBox buildMetricCard(String title, String value, String icon) {
        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-font-size: 26px;");

        Label titleLabel = new Label(title);
        titleLabel.setStyle(
                "-fx-font-size: 13px;" +
                        "-fx-text-fill: #546e7a;"
        );

        Label valueLabel = new Label(value);
        valueLabel.setStyle(
                "-fx-font-size: 22px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-text-fill: #263238;"
        );

        VBox box = new VBox(6, iconLabel, titleLabel, valueLabel);
        box.setAlignment(Pos.CENTER_LEFT);
        box.setPadding(new Insets(14));
        box.setPrefWidth(180);

        box.setStyle(
                "-fx-background-color: rgba(255,255,255,0.92);" +
                        "-fx-background-radius: 18;" +
                        "-fx-border-radius: 18;" +
                        "-fx-border-width: 1.2;" +
                        "-fx-border-color: rgba(120,144,156,0.35);" +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 10, 0, 0, 4);"
        );

        return box;
    }

    //Theme
    private void applyTheme() {
        if (!darkMode) {
            // Light theme
            mainRoot.setStyle(
                    "-fx-background-color: linear-gradient(to bottom right, #e0f7fa, #ede7f6);" +
                            "-fx-font-family: 'Segoe UI', 'Arial';"
            );
            headerBar.setStyle(
                    "-fx-background-color: rgba(255,255,255,0.95);" +
                            "-fx-background-radius: 0 0 18 18;" +
                            "-fx-border-radius: 0 0 18 18;" +
                            "-fx-border-width: 0 0 1 0;" +
                            "-fx-border-color: rgba(0,0,0,0.08);"
            );
            tabPane.setStyle(
                    "-fx-background-color: transparent;" +
                            "-fx-tab-min-height: 40;" +
                            "-fx-tab-max-height: 80;"
            );
        } else {
            // Dark theme
            mainRoot.setStyle(
                    "-fx-background-color: linear-gradient(to bottom right, #111827, #1f2937);" +
                            "-fx-font-family: 'Segoe UI', 'Arial';"
            );
            headerBar.setStyle(
                    "-fx-background-color: rgba(15,23,42,0.96);" +
                            "-fx-background-radius: 0 0 18 18;" +
                            "-fx-border-radius: 0 0 18 18;" +
                            "-fx-border-width: 0 0 1 0;" +
                            "-fx-border-color: rgba(148,163,184,0.5);"
            );
            tabPane.setStyle(
                    "-fx-background-color: transparent;" +
                            "-fx-tab-min-height: 40;" +
                            "-fx-tab-max-height: 80;" +
                            "-fx-base: #0f172a;" +
                            "-fx-text-base-color: #e5e7eb;"
            );
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
