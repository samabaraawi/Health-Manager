package ds;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class TreatmentsTab extends Tab {

    private final PatientManager pm;
    private final ConditionManager cm;

    private final TableView<TreatmentRow> table = new TableView<>();
    private ComboBox<String> cbSort;
    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public TreatmentsTab(PatientManager pm, ConditionManager cm) {
        this.pm = pm;
        this.cm = cm;

        setText("Treatments");
        setClosable(false);
        setContent(buildContent());
        refreshTable();
    }


    public static class TreatmentRow {
        final String patientId;
        final String patientName;
        final String conditionName;
        final String treatmentId;
        String type;
        String startDate;
        String endDate;

        public TreatmentRow(String patientId, String patientName, String conditionName,
                            String treatmentId, String type, String startDate, String endDate) {
            this.patientId = patientId;
            this.patientName = patientName;
            this.conditionName = conditionName;
            this.treatmentId = treatmentId;
            this.type = type;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        public String getPatientId()    { return patientId; }
        public String getPatientName()  { return patientName; }
        public String getConditionName(){ return conditionName; }
        public String getTreatmentId()  { return treatmentId; }
        public String getType()         { return type; }
        public String getStartDate()    { return startDate; }
        public String getEndDate()      { return endDate; }
    }


    private BorderPane buildContent() {
        TableColumn<TreatmentRow, String> cPid   = new TableColumn<>("Patient ID");
        TableColumn<TreatmentRow, String> cPName = new TableColumn<>("Patient Name");
        TableColumn<TreatmentRow, String> cCond  = new TableColumn<>("Condition");
        TableColumn<TreatmentRow, String> cTid   = new TableColumn<>("Treatment ID");
        TableColumn<TreatmentRow, String> cType  = new TableColumn<>("Type");
        TableColumn<TreatmentRow, String> cStart = new TableColumn<>("Start");
        TableColumn<TreatmentRow, String> cEnd   = new TableColumn<>("End");

        cPid.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getPatientId()));
        cPName.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getPatientName()));
        cCond.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getConditionName()));
        cTid.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getTreatmentId()));
        cType.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getType()));
        cStart.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getStartDate()));
        cEnd.setCellValueFactory(v -> new javafx.beans.property.SimpleStringProperty(v.getValue().getEndDate()));

        table.getColumns().addAll(cPid, cPName, cCond, cTid, cType, cStart, cEnd);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // أزرار CRUD
        Button btnAdd = new Button("Add");
        Button btnEdit = new Button("Edit");
        Button btnDel = new Button("Delete");
        Button btnRefresh = new Button("Refresh");

        btnAdd.setOnAction(e -> onAdd());
        btnEdit.setOnAction(e -> onEdit());
        btnDel.setOnAction(e -> onDelete());
        btnRefresh.setOnAction(e -> refreshTable());

        cbSort = new ComboBox<>();
        cbSort.getItems().addAll(
                "Patient ID",
                "Patient Name",
                "Condition",
                "Treatment Type",
                "Start Date",
                "End Date"
        );
        cbSort.setValue("Patient ID");

        Button btnApplySort = new Button("Apply Sort");
        btnApplySort.setOnAction(e -> refreshTable());

        HBox sortBox = new HBox(8, new Label("Sort by:"), cbSort, btnApplySort);
        sortBox.setPadding(new Insets(10));

        HBox crudBox = new HBox(10, btnAdd, btnEdit, btnDel, btnRefresh);
        crudBox.setPadding(new Insets(10));

        HBox top = new HBox(20, crudBox, sortBox);

        BorderPane root = new BorderPane();
        root.setTop(top);
        root.setCenter(table);
        return root;
    }


    private ObservableList<TreatmentRow> buildRows() {
        ObservableList<TreatmentRow> rows = FXCollections.observableArrayList();
        CircularDoublyLinkedList<Patient> ps = pm.getPatients();
        int pn = ps.getSize();
        for (int i = 0; i < pn; i++) {
            Patient p = ps.get(i);
            if (p == null) continue;
            String condName = p.getConditionName();
            CircularDoublyLinkedList<Treatment> ts = p.getTreatments();
            int tn = ts.getSize();
            for (int j = 0; j < tn; j++) {
                Treatment t = ts.get(j);
                if (t == null) continue;
                rows.add(new TreatmentRow(
                        p.getId(), p.getName(), condName,
                        t.getId(), t.getType(), t.getStartDate(), t.getEndDate()
                ));
            }
        }
        return rows;
    }


    private void applySorting(ObservableList<TreatmentRow> rows) {
        String crit = cbSort.getValue();
        if (crit == null) return;

        FXCollections.sort(rows, (a, b) -> {
            switch (crit) {
                case "Patient ID":
                    return cmpStr(a.patientId, b.patientId);
                case "Patient Name":
                    return cmpStr(a.patientName, b.patientName);
                case "Condition":
                    return cmpStr(a.conditionName, b.conditionName);
                case "Treatment Type":
                    return cmpStr(a.type, b.type);
                case "Start Date":
                    return cmpStr(a.startDate, b.startDate);
                case "End Date":
                    return cmpStr(a.endDate, b.endDate);
                default:
                    return 0;
            }
        });
    }

    private int cmpStr(String s1, String s2) {
        if (s1 == null && s2 == null) return 0;
        if (s1 == null) return 1;
        if (s2 == null) return -1;
        return s1.compareToIgnoreCase(s2);
    }


    public void refreshTable() {
        ObservableList<TreatmentRow> rows = buildRows();
        applySorting(rows);
        table.setItems(rows);
    }


    private void onAdd() {
        Dialog<TreatmentRow> dlg = buildAddDialog();
        dlg.showAndWait().ifPresent(row -> {
            Patient p = pm.findById(row.patientId);
            if (p == null) { showAlert("Add Treatment", "Patient not found."); return; }

            Condition cond = (p.getConditionName() == null) ? null : cm.findByName(p.getConditionName());
            Treatment t = new Treatment(row.treatmentId, row.type, row.startDate, row.endDate);

            boolean ok = p.addTreatmentIfAllowed(t, cond);
            if (!ok) {
                showAlert("Add Treatment", "Not allowed for patient's condition or invalid input.");
            }
            refreshTable();
        });
    }


    private void onEdit() {
        TreatmentRow sel = table.getSelectionModel().getSelectedItem();
        if (sel == null) {
            showAlert("Edit Treatment", "Select a treatment first.");
            return;
        }

        Patient p = pm.findById(sel.patientId);
        if (p == null) {
            showAlert("Edit Treatment", "Patient not found.");
            return;
        }

        Dialog<TreatmentRow> dlg = buildEditDialog(sel, p);
        dlg.showAndWait().ifPresent(newRow -> {
            boolean removed = p.removeTreatmentById(sel.treatmentId);
            if (!removed) {
                showAlert("Edit Treatment", "Original treatment not found.");
                refreshTable();
                return;
            }

            Condition cond = (p.getConditionName() == null) ? null : cm.findByName(p.getConditionName());
            Treatment tNew = new Treatment(newRow.treatmentId, newRow.type, newRow.startDate, newRow.endDate);

            boolean ok = p.addTreatmentIfAllowed(tNew, cond);
            if (!ok) {
                showAlert("Edit Treatment", "Not allowed for patient's condition. Reverting original.");
                Treatment tOld = new Treatment(sel.treatmentId, sel.type, sel.startDate, sel.endDate);
                p.addTreatment(tOld);
            }
            refreshTable();
        });
    }


    private void onDelete() {
        TreatmentRow sel = table.getSelectionModel().getSelectedItem();
        if (sel == null) { showAlert("Delete Treatment", "Select a treatment first."); return; }
        Patient p = pm.findById(sel.patientId);
        if (p == null) { showAlert("Delete Treatment", "Patient not found."); return; }
        boolean ok = p.removeTreatmentById(sel.treatmentId);
        if (!ok) showAlert("Delete Treatment", "Delete failed.");
        refreshTable();
    }

    private Dialog<TreatmentRow> buildAddDialog() {
        Dialog<TreatmentRow> d = new Dialog<>();
        d.setTitle("Add Treatment");

        Label lPid   = new Label("Patient ID:");
        Label lTid   = new Label("Treatment ID:");
        Label lType  = new Label("Type:");
        Label lStart = new Label("Start (DD.MM.YYYY):");
        Label lEnd   = new Label("End (DD.MM.YYYY):");

        ComboBox<String> cbPatient = new ComboBox<>();
        TextField tfTid = new TextField();
        ComboBox<String> cbType = new ComboBox<>();
        DatePicker dpStart = new DatePicker();
        DatePicker dpEnd   = new DatePicker();

        dpStart.setPromptText("dd.MM.yyyy");
        dpEnd.setPromptText("dd.MM.yyyy");

        int pn = pm.count();
        CircularDoublyLinkedList<Patient> ps = pm.getPatients();
        for (int i = 0; i < pn; i++) {
            Patient p = ps.get(i);
            if (p != null) cbPatient.getItems().add(p.getId());
        }


        cbPatient.valueProperty().addListener((obs, oldV, newV) -> {
            cbType.getItems().clear();
            Patient p = pm.findById(newV);
            if (p != null) {
                String cname = p.getConditionName();
                Condition c = (cname == null) ? null : cm.findByName(cname);
                if (c != null) {
                    CircularDoublyLinkedList<String> treats = c.getRecTreats();
                    int tn = treats.getSize();
                    for (int i = 0; i < tn; i++) cbType.getItems().add(treats.get(i));
                }
            }
        });

        GridPane gp = new GridPane();
        gp.setHgap(10); gp.setVgap(10); gp.setPadding(new Insets(10));
        gp.addRow(0, lPid, cbPatient);
        gp.addRow(1, lTid, tfTid);
        gp.addRow(2, lType, cbType);
        gp.addRow(3, lStart, dpStart);
        gp.addRow(4, lEnd, dpEnd);

        d.getDialogPane().setContent(gp);
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        d.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String patientId = cbPatient.getValue();
                String tid = tfTid.getText().trim();
                String type = cbType.getValue();
                LocalDate ldStart = dpStart.getValue();
                LocalDate ldEnd   = dpEnd.getValue();

                String start = (ldStart == null ? "" : ldStart.format(DATE_FMT));
                String end   = (ldEnd   == null ? "" : ldEnd.format(DATE_FMT));

                if (patientId == null || patientId.isEmpty() || tid.isEmpty() || type == null)
                    return null;

                Patient p = pm.findById(patientId);
                String pname = (p == null) ? "" : p.getName();
                String cname = (p == null) ? null : p.getConditionName();
                return new TreatmentRow(patientId, pname, cname, tid, type, start, end);
            }
            return null;
        });

        return d;
    }

    private Dialog<TreatmentRow> buildEditDialog(TreatmentRow original, Patient p) {
        Dialog<TreatmentRow> d = new Dialog<>();
        d.setTitle("Edit Treatment");

        Label lPid   = new Label("Patient ID:");
        Label lTid   = new Label("Treatment ID:");
        Label lType  = new Label("Type:");
        Label lStart = new Label("Start (DD.MM.YYYY):");
        Label lEnd   = new Label("End (DD.MM.YYYY):");

        TextField tfPid = new TextField(original.patientId);
        tfPid.setDisable(true);

        TextField tfTid = new TextField(original.treatmentId);

        ComboBox<String> cbType = new ComboBox<>();
        DatePicker dpStart = new DatePicker();
        DatePicker dpEnd   = new DatePicker();

        dpStart.setPromptText("dd.MM.yyyy");
        dpEnd.setPromptText("dd.MM.yyyy");

        Condition c = (p.getConditionName() == null) ? null : cm.findByName(p.getConditionName());
        if (c != null) {
            CircularDoublyLinkedList<String> treats = c.getRecTreats();
            int tn = treats.getSize();
            for (int i = 0; i < tn; i++) cbType.getItems().add(treats.get(i));
        }
        cbType.setValue(original.type);

        if (original.startDate != null && !original.startDate.trim().isEmpty()) {
            try {
                LocalDate ld = LocalDate.parse(original.startDate, DATE_FMT);
                dpStart.setValue(ld);
            } catch (Exception ignored) {}
        }
        if (original.endDate != null && !original.endDate.trim().isEmpty()) {
            try {
                LocalDate ld = LocalDate.parse(original.endDate, DATE_FMT);
                dpEnd.setValue(ld);
            } catch (Exception ignored) {}
        }

        GridPane gp = new GridPane();
        gp.setHgap(10); gp.setVgap(10); gp.setPadding(new Insets(10));
        gp.addRow(0, lPid, tfPid);
        gp.addRow(1, lTid, tfTid);
        gp.addRow(2, lType, cbType);
        gp.addRow(3, lStart, dpStart);
        gp.addRow(4, lEnd, dpEnd);

        d.getDialogPane().setContent(gp);
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        d.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                String tid = tfTid.getText().trim();
                String type = cbType.getValue();
                LocalDate ldStart = dpStart.getValue();
                LocalDate ldEnd   = dpEnd.getValue();

                String start = (ldStart == null ? "" : ldStart.format(DATE_FMT));
                String end   = (ldEnd   == null ? "" : ldEnd.format(DATE_FMT));

                if (tid.isEmpty() || type == null) return null;
                return new TreatmentRow(original.patientId, original.patientName, original.conditionName,
                        tid, type, start, end);
            }
            return null;
        });

        return d;
    }


    private void showAlert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title); a.setHeaderText(null); a.setContentText(msg);
        a.showAndWait();
    }
}
